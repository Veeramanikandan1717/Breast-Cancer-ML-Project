from flask import Flask, request, render_template, redirect, url_for, flash
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import missingno as msno
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix
import os
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

app = Flask(__name__)
app.secret_key = "42770288972d5511f236ad014e8d7a79"

UPLOAD_FOLDER = 'uploads'
PLOTS_FOLDER = 'static/plots'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PLOTS_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Initialize ChatBot
chatbot = ChatBot("WebChatBot")
trainer = ChatterBotCorpusTrainer(chatbot)
trainer.train("chatterbot.corpus.english")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    # Existing code for file upload and analysis...
    # (No changes here except your existing code.)
    file = request.files.get('file')
    if not file:
        flash("No file uploaded!")
        return redirect(url_for('home'))
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)
    
    try:
        # Load CSV into DataFrame
        df = pd.read_csv(file_path)

        if 'diagnosis' not in df.columns:
            raise KeyError("The 'diagnosis' column is missing from the DataFrame.")
        
        # Preprocessing
        df['diagnosis'] = df['diagnosis'].apply(lambda val: 1 if val == 'M' else 0)
        columns_to_drop = ['id', 'Unnamed: 32']
        df.drop(columns=[col for col in columns_to_drop if col in df.columns], inplace=True)
        
        # Generate and save missing data plot
        plt.figure()
        msno.bar(df, color='red')
        missing_plot_path = os.path.join(PLOTS_FOLDER, 'missing_data_plot.png')
        plt.savefig(missing_plot_path)
        plt.close()
        
        # Generate and save correlation heatmap
        plt.figure(figsize=(20, 12))
        corr = df.corr()
        mask = np.triu(np.ones_like(corr, dtype=bool))
        sns.heatmap(corr, mask=mask, linewidths=1, annot=True, fmt=".2f", cmap="viridis")
        heatmap_path = os.path.join(PLOTS_FOLDER, 'correlation_heatmap.png')
        plt.savefig(heatmap_path)
        plt.close()

        # Generate and save diagnosis histogram
        plt.figure()
        plt.hist(df['diagnosis'], bins=2, color='skyblue', edgecolor='black')
        plt.title('Diagnosis (M=1, B=0)')
        plt.xlabel('Diagnosis')
        plt.ylabel('Count')
        diagnosis_histogram_path = os.path.join(PLOTS_FOLDER, 'diagnosis_histogram.png')
        plt.savefig(diagnosis_histogram_path)
        plt.close()
        
        # Statistical summary (numerical summary)
        numerical_summary = df.describe().transpose()
        numerical_summary_html = numerical_summary.style.background_gradient(cmap="viridis").to_html()

        # Generate and save EDA distribution plots for each column
        plt.figure(figsize=(20, 15))
        plotnumber = 1
        for column in df:
            if plotnumber <= 30:  # Limiting to 30 plots to fit in the figure
                ax = plt.subplot(5, 6, plotnumber)
                sns.histplot(df[column], kde=True)
                plt.xlabel(column)
            plotnumber += 1
        plt.tight_layout()
        eda_distribution_path = os.path.join(PLOTS_FOLDER, 'eda_distribution_plot.png')
        plt.savefig(eda_distribution_path)
        plt.close()

        # Model training
        X = df.drop('diagnosis', axis=1)
        y = df['diagnosis']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
        
        scaler = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_test = scaler.transform(X_test)
        
        model = LogisticRegression()
        model.fit(X_train, y_train)
        training_accuracy = accuracy_score(y_train, model.predict(X_train))
        
        # Generate and save confusion matrix
        y_pred = model.predict(X_test)
        plt.figure(figsize=(10, 7))
        sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt='d', cmap='viridis')
        plt.xlabel('Predicted Labels')
        plt.ylabel('True Labels')
        plt.title('Confusion Matrix Heatmap')
        confusion_matrix_path = os.path.join(PLOTS_FOLDER, 'confusion_matrix_heatmap.png')
        plt.savefig(confusion_matrix_path)
        plt.close()
        
        flash(f"Training Accuracy: {training_accuracy:.2f}")
        
        return render_template('results.html', 
                               columns=df.columns, 
                               accuracy=training_accuracy,
                               missing_plot_path=missing_plot_path,
                               heatmap_path=heatmap_path,
                               diagnosis_histogram_path=diagnosis_histogram_path,
                               eda_distribution_path=eda_distribution_path,
                               confusion_matrix_path=confusion_matrix_path,
                               numerical_summary=numerical_summary_html)

    except Exception as e:
        flash(str(e))
        return redirect(url_for('home'))

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message')
    response = chatbot.get_response(user_message)
    return {'response': str(response)}

if __name__ == '__main__':
    app.run(debug=True)
